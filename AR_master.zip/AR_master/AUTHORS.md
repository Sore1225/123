This program was developed by,

- Jayant Jain
- Manuj Trehan

However, it does also contain pieces of code from the following repositories:

- [augmented-reality](https://github.com/juangallostra/augmented-reality) by Juan Gallostra Acín:

Original disclaimers in the code of these have been maintained as much as possible.
Please contact Jayant Jain (jayantjain100@gmail.com) if you feel this has not been done correctly.